self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7995c951eb07b7d25a0d7fb6d7f386f3",
    "url": "/index.html"
  },
  {
    "revision": "d367acd06bb16423b970",
    "url": "/static/css/main.b582cacd.chunk.css"
  },
  {
    "revision": "a6ea957c7717ad20dfee",
    "url": "/static/js/2.0919b747.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/2.0919b747.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d367acd06bb16423b970",
    "url": "/static/js/main.f2d888fb.chunk.js"
  },
  {
    "revision": "559ff28579f192bdf8b9",
    "url": "/static/js/runtime-main.98bec8e4.js"
  },
  {
    "revision": "f6deeab0662393a8341c56c623c547d6",
    "url": "/static/media/ban.f6deeab0.jpg"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/static/media/logo.5d5d9eef.svg"
  }
]);